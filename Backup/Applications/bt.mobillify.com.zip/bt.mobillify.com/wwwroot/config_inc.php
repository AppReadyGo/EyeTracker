<?php
	$g_hostname = 'localhost';
	$g_db_type = 'mysql';
	$g_database_name = 'ypanshin_mobillify_bt';
	$g_db_username = 'ypanshin_m_bt';
	$g_db_password = 'xEkl7BVs6XEaH';
	$g_from_email = 'bugtracker@mobillify.com';
	$g_from_name	 = 'Mobillify Bug Tracker';
	$g_return_path_email	= 'bugtracker@mobillify.com';
	$g_administrator_email	= 'bugtracker@mobillify.com';
	$g_webmaster_email	 = 'bugtracker@mobillify.com';
	$g_enable_email_notification	= ON;
	$g_email_receive_own	= OFF;
	$g_phpMailer_method	 = 2;
	$g_smtp_host	 = 'smtp.gmail.com';
	$g_smtp_username = 'bugtracker@mobillify.com';
	$g_smtp_password = 'jJ7wIaEZ9r';
	$g_smtp_port = '465';
	$g_smtp_connection_mode = 'ssl';
	$g_file_upload_method = DISK;
	$g_absolute_path_default_upload_folder = 'upload/'
?>