window.onload = function() {
	  setTimeout(function(){window.scrollTo(0, 1);}, 100);
	} 