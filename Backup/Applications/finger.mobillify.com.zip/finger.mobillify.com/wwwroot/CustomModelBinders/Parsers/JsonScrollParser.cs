﻿namespace EyeTracker.CustomModelBinders.Parsers
{
    public class JsonScrollParser : IParser
    {
        #region IParser Members

        public object ParseToEvent(System.Web.Mvc.ModelStateDictionary mState, IPackage package)
        {
            throw new System.NotImplementedException();
        }

        #endregion
    }
}