﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EyeTracker.Model.Pages.Account
{
    public class ForgotPasswordModel
    {
        public string Email { get; set; }
    }
}