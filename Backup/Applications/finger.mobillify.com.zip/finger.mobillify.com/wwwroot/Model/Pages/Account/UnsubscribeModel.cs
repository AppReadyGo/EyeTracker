﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EyeTracker.Model.Pages.Account
{
    public class UnsubscribeModel
    {
        public string Email { get; set; }
    }
}